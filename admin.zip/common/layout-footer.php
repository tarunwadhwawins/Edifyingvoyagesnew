<!--scripts-->
<script type="text/javascript" src="assets/js/jquery-3.5.0.min.js"></script>
<script type="text/javascript" src="assets/js/bootstrap.bundle.min.js"></script>
<script type="text/javascript" src="assets/js/owl.carousel.min.js"></script>
<script type="text/javascript" src="assets/js/jquery.easy-pie-chart.js"></script>
<script type="text/javascript" src="assets/js/scripts.js"></script>
<!---->
</body>

</html>