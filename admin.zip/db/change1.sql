ALTER TABLE `blogs`
  DROP `seo_title`,
  DROP `seo_keyword`,
  DROP `seo_desc`;