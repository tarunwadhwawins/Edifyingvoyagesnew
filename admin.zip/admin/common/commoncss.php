    <link rel="icon" type="image/x-icon" href="../admin/assets/images/favicon.png"/>
    <link rel="stylesheet" href="../admin/assets/css/style.css">
    <link rel="stylesheet" href="../admin/assets/css/common.css">
    <link rel="stylesheet" href="assets/css/bootstrap-multiselect.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="//code.jquery.com/ui/1.13.0/themes/base/jquery-ui.css">