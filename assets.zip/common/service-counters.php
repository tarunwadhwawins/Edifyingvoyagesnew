<div class="col-md-3 col-sm-6">
    <div class="counter">
        <span class="counter-value">566</span>
        <h3>Projects</h3>
    </div>
</div>
<div class="col-md-3 col-sm-6">
    <div class="counter">
        <span class="counter-value">534</span>
        <h3>Happy Clients</h3>
    </div>
</div>
<div class="col-md-3 col-sm-6">
    <div class="counter">
        <span class="counter-value">534</span>
        <h3>Revenue Generated</h3>
    </div>
</div>
<div class="col-md-3 col-sm-6">
    <div class="counter">
        <span class="counter-value">534</span>
        <h3>Revenue Generated</h3>
    </div>
</div>