<!---->
<?php include_once('common/layout-header.php'); ?>
<!---->
<?php include_once('common/header.php'); ?>
<!---->
<div class="main pt-70">
    <!---->
    <section class="about-section ptb-100" style="background: url('assets/images/contact-us-banner.webp')no-repeat center center / cover">
        <div class="container-xl">
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-7">
                    <div class="page-header-content text-center pt-sm-5 pt-md-5 pt-lg-0">
                        <h1 class="color-white mb-0">Contact Us</h1>
                        <!-- <div class="custom-breadcrumb">
                            <ol class="breadcrumb d-inline-block bg-transparent list-inline py-0">
                                <li class="list-inline-item breadcrumb-item"><a href="#">Home</a></li>
                                <li class="list-inline-item breadcrumb-item active">Contact Us</li>
                            </ol>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!---->
    <?php include_once('common/queries-form.php'); ?>
    <!---->
</div>
<!--footer section start-->
<?php include_once('common/footer.php'); ?>
<!---->
<?php include_once('common/layout-footer.php'); ?>