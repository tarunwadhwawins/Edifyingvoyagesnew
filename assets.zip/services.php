<!---->
<?php include_once('common/layout-header.php'); ?>
<!---->
<?php include_once('common/header.php'); ?>
<!---->
<div class="main pt-70">
    <!---->
    <section class="about-section ptb-100" style="background: url('assets/images/services-banner.webp')no-repeat center center / cover">
        <div class="container-xl">
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-7">
                    <div class="page-header-content text-center pt-sm-5 pt-md-5 pt-lg-0">
                        <h1 class="color-white mb-0">Services</h1>
                        <!-- <div class="custom-breadcrumb">
                            <ol class="breadcrumb d-inline-block bg-transparent list-inline py-0">
                                <li class="list-inline-item breadcrumb-item"><a href="#">Home</a></li>
                                <li class="list-inline-item breadcrumb-item active">Services</li>
                            </ol>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!---->
    <section class="promo-section ptb-100">
        <div class="container-xl">
            <div class="row justify-content-center">
                <div class="col-md-6 col-lg-4">
                    <div class="promo-single-wrap p-5 text-center custom-shadow rounded">
                        <div class="promo-icon mb-4">
                            <i class="ti-dashboard"></i>
                            <span class="number-bg">01</span>
                        </div>
                        <div class="promo-info">
                            <strong class="color-secondary">Discuss with Users</strong>
                            <h4>Site Optimisation</h4>
                            <p>What is business contents insurance? Business contents insurance is a type of
                                business.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="promo-single-wrap p-5 text-center custom-shadow rounded">
                        <div class="promo-icon mb-4">
                            <i class="ti-pulse"></i>
                            <span class="number-bg">02</span>
                        </div>
                        <div class="promo-info">
                            <strong class="color-secondary">Discuss with Users</strong>
                            <h4>Increased Traffic</h4>
                            <p>What is business contents insurance? Business contents insurance is a type of
                                business.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="promo-single-wrap p-5 text-center custom-shadow rounded">
                        <div class="promo-icon mb-4">
                            <i class="ti-vector"></i>
                            <span class="number-bg">03</span>
                        </div>
                        <div class="promo-info">
                            <strong class="color-secondary">Discuss with Users</strong>
                            <h4>Digital Marketing</h4>
                            <p>What is business contents insurance? Business contents insurance is a type of
                                business.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!---->
    <section class="services-section ptb-100 gray-light-bg">
        <div class="container-xl">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="section-heading text-center mb-4">
                        <strong class="color-secondary">Our Services</strong>
                        <h2>Our Digital Marketing Expertise</h2>
                        <span class="animate-border me-auto ms-auto mb-4"></span>
                        <p class="lead">We offer a complete set of integrated services to drive your business digital growth. Get a overview of our services!</p>
                    </div>
                </div>
            </div>
            <?php include_once('common/service-section.php'); ?>
        </div>
    </section>
    <!---->
    <section class="call-to-action ptb-70">
        <div class="container-xl">
            <div class="row">
                <?php include_once('common/service-counters.php'); ?>
            </div>
        </div>
    </section>
    <!---->
    <?php include_once('common/consulting-section.php'); ?>
    <!---->
</div>
<!--footer section start-->
<?php include_once('common/footer.php'); ?>
<!---->
<?php include_once('common/layout-footer.php'); ?>