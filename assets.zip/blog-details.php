<!---->
<?php include_once('common/layout-header.php'); ?>
<!---->
<?php include_once('common/header.php'); ?>
<!---->
<div class="main pt-70">
    <!---->
    <section class="about-section ptb-100" style="background: url('assets/images/header-bg-5.jpg')no-repeat center center / cover">
        <div class="container-xl">
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-7">
                    <div class="page-header-content text-center pt-sm-5 pt-md-5 pt-lg-0">
                        <h1 class="color-white mb-0">Blog</h1>
                        <div class="custom-breadcrumb">
                            <ol class="breadcrumb d-inline-block bg-transparent list-inline py-0">
                                <li class="list-inline-item breadcrumb-item"><a href="#">Home</a></li>
                                <li class="list-inline-item breadcrumb-item active">Blog</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!---->
    <section class="module ptb-100">
        <div class="container-xl">
            <div class="row">
            <div class="col-lg-8 col-md-8">
                    <!-- Post-->
                    <article class="post">
                        <div class="post-preview"><img src="assets/images/blog/1-w.jpg" alt="article" class="img-fluid"/></div>
                        <div class="post-wrapper">
                            <div class="post-header">
                                <h1 class="post-title">Minimalist Chandelier</h1>
                                <ul class="post-meta">
                                    <li>November 18, 2016</li>
                                    <li>In <a href="#">Branding</a>, <a href="#">Design</a></li>
                                </ul>
                            </div>
                            <div class="post-content">
                                <p>Meh synth Schlitz, tempor duis single-origin coffee ea next level ethnic fingerstache fanny pack nostrud. Seitan High Life reprehenderit consectetur cupidatat kogi about me. Photo booth anim 8-bit hella, PBR 3 wolf moon beard Helvetica. Salvia esse nihil, flexitarian Truffaut synth art party deep v chillwave. Seitan High Life reprehenderit consectetur cupidatat kogi.</p>
                                <p>Exercitation photo booth stumptown tote bag Banksy, elit small batch freegan sed. Craft beer elit seitan exercitation, photo booth et 8-bit kale chips proident chillwave deep v laborum. Aliquip veniam delectus, Marfa eiusmod Pinterest in do umami readymade swag. Selfies iPhone Kickstarter, drinking vinegar jean shorts fixie consequat flexitarian four loko.</p>
                                <p>Meh synth Schlitz, tempor duis single-origin coffee ea next level ethnic fingerstache fanny pack nostrud. Seitan High Life reprehenderit consectetur cupidatat kogi about me. Photo booth anim 8-bit hella, PBR 3 wolf moon beard Helvetica.</p>
                                <p>Meh synth Schlitz, tempor duis single-origin coffee ea next level ethnic fingerstache fanny pack nostrud. Seitan High Life reprehenderit consectetur cupidatat kogi about me. Photo booth anim 8-bit hella, PBR 3 wolf moon beard Helvetica. Salvia esse nihil, flexitarian Truffaut synth art party deep v chillwave. Seitan High Life reprehenderit consectetur cupidatat kogi.</p>
                                <ol>
                                    <li>Digital Strategy</li>
                                    <li>Software Development</li>
                                    <li>Interaction Design</li>
                                </ol>
                                <p>Meh synth Schlitz, tempor duis single-origin coffee ea next level ethnic fingerstache fanny pack nostrud. Seitan High Life reprehenderit consectetur cupidatat kogi about me. Photo booth anim 8-bit hella, PBR 3 wolf moon beard Helvetica.</p>
                                <p>Exercitation photo booth stumptown tote bag Banksy, elit small batch freegan sed. Craft beer elit seitan exercitation, photo booth et 8-bit kale chips proident chillwave deep v laborum. Aliquip veniam delectus, Marfa eiusmod Pinterest in do umami readymade swag. Selfies iPhone Kickstarter, drinking vinegar jean shorts fixie consequat flexitarian four loko.</p>
                            </div>
                            <div class="post-footer">
                                <div class="post-tags"><a href="#">Lifestyle</a><a href="#">Music</a><a href="#">News</a><a href="#">Travel</a></div>
                            </div>
                        </div>
                    </article>
                    <!-- Post end-->
                </div>
                <div class="col-lg-4 col-md-4">
                    <div class="sidebar-left pr-4">
                        <aside class="widget widget-search">
                            <form>
                                <input class="form-control" type="search" placeholder="Type Search Words">
                                <button class="search-button" type="submit"><span class="ti-search"></span></button>
                            </form>
                        </aside>
                        <aside class="widget widget-categories">
                            <div class="widget-title">
                                <h6>Categories</h6>
                            </div>
                            <ul>
                                <li><a href="#">Journey <span class="float-right">112</span></a></li>
                                <li><a href="#">Development <span class="float-right">86</span></a></li>
                                <li><a href="#">Sport <span class="float-right">10</span></a></li>
                                <li><a href="#">Photography <span class="float-right">144</span></a></li>
                                <li><a href="#">Symphony <span class="float-right">18</span></a></li>
                            </ul>
                        </aside>
                        <aside class="widget widget-recent-entries-custom">
                            <div class="widget-title">
                                <h6>Recent Posts</h6>
                            </div>
                            <ul>
                                <li class="clearfix">
                                    <div class="wi"><a href="#"><img src="assets/images/blog/1.jpg" alt="recent post" class="img-fluid rounded"/></a></div>
                                    <div class="wb"><a href="#">Map where your photos were taken and discover local points.</a><span class="post-date">May 8, 2016</span></div>
                                </li>
                                <li class="clearfix">
                                    <div class="wi"><a href="#"><img src="assets/images/blog/1.jpg" alt="recent post" class="img-fluid rounded"/></a></div>
                                    <div class="wb"><a href="#">Map where your photos were taken and discover local points.</a><span class="post-date">May 8, 2016</span></div>
                                </li>
                                <li class="clearfix">
                                    <div class="wi"><a href="#"><img src="assets/images/blog/1.jpg" alt="recent post" class="img-fluid rounded"/></a></div>
                                    <div class="wb"><a href="#">Map where your photos were taken and discover local points.</a><span class="post-date">May 8, 2016</span></div>
                                </li>
                            </ul>
                        </aside>
                        <aside class="widget widget-categories">
                            <div class="widget-title">
                                <h6>Newsletter</h6>
                            </div>
                            <p>Enter your email address below to subscribe to my newsletter</p>
                            <form action="#" method="post"
                                  class="d-none d-md-block d-lg-block">
                                <input type="text" class="form-control input" id="email-footer" name="email"
                                       placeholder="info@yourdomain.com">
                                <button type="submit" class="btn secondary-solid-btn btn-block btn-not-rounded mt-3">Subscribe</button>
                            </form>
                        </aside>
                        <aside class="widget widget-tag-cloud">
                            <div class="widget-title">
                                <h6>Tags</h6>
                            </div>
                            <div class="tag-cloud"><a href="#">e-commerce</a><a href="#">portfolio</a><a href="#">responsive</a><a href="#">bootstrap</a><a href="#">business</a><a href="#">corporate</a></div>
                        </aside>
                    </div>
                </div>
      
            </div>
        </div>
    </section>
    <!---->
</div>
<!--footer section start-->
<?php include_once('common/footer.php'); ?>
<!---->
<?php include_once('common/layout-footer.php'); ?>